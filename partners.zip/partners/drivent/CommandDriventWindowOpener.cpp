/*
*
*	Drivent window opener
*	ParnterCode    		= 0xF0
*	DeviceType 			= 0x04 (Window Opener)
*	DeviceModel 		= 0x0 + PartnerCode = 0xF0
*	HardwareRevision 	= any
*
*/

#include "CommandDriventWindowOpener.h"

#include "Settings.h"
#include "HardwareIO.h"
#include "JSON.h"
#include "WebServer.h"
#include "Query.h"
#include "PowerManagement.h"

const char DriventWOTag[] 								= "DriventWindowOpener";

CommandDriventWindowOpener_t::CommandDriventWindowOpener_t() 
{
}

void CommandDriventWindowOpener_t::InitSettings() {
	if (IsInited)
		return;

	IsInited = true;

	if (Settings.GPIOData.GetCurrent().WindowOpener.Button1 != GPIO_NUM_0)
	{
		Button1 = Settings.GPIOData.GetCurrent().WindowOpener.Button1;
		GPIO::Setup(Button1 , GPIO_MODE_INPUT);
		::gpio_pullup_en(Button1);
	}

	if (Settings.GPIOData.GetCurrent().WindowOpener.Button2 != GPIO_NUM_0)
	{
		Button2 = Settings.GPIOData.GetCurrent().WindowOpener.Button2;
		GPIO::Setup(Button2 , GPIO_MODE_INPUT);
		::gpio_pullup_en(Button2);
	}

	GPIO::Setup(V_POWER		, GPIO_MODE_INPUT); 		// Датчик Напряжение питания
	GPIO::Setup(I_DRIVE		, GPIO_MODE_INPUT); 		// Датчик тока нагрузки
	GPIO::Setup(RAINSENSOR	, GPIO_MODE_INPUT); 		// Датчик дождя
	GPIO::Setup(V_REF		, GPIO_MODE_INPUT); 		// Источник опорного Напряжение датчика тока
	GPIO::Setup(SENS_PIN	, GPIO_MODE_INPUT); 		// Датчик положение мотора

	adc1_config_width(ADC_WIDTH_BIT_12);					// Разрешение АЦП ставим 12 бит

	CurrentTime = 0;

	/* settings */
	// определяем частоту и разрядность ШИМ для двигателя.
	
	if (Settings.GPIOData.GetCurrent().WindowOpener.MotorGPIO1.GPIO != GPIO_NUM_0)
	{
		MotorDataGPIO1 = Settings.GPIOData.GetCurrent().WindowOpener.MotorGPIO1;
		GPIO::SetupPWM(MotorDataGPIO1.GPIO, MotorDataGPIO1.Channel, MotorDataGPIO1.Frequency, MotorDataGPIO1.Resolution, LEDC_TIMER_MAX, LEDC_AUTO_CLK);
	}

	if (Settings.GPIOData.GetCurrent().WindowOpener.MotorGPIO2.GPIO != GPIO_NUM_0)
	{
		MotorDataGPIO2 = Settings.GPIOData.GetCurrent().WindowOpener.MotorGPIO2;
		GPIO::SetupPWM(MotorDataGPIO2.GPIO, MotorDataGPIO2.Channel, MotorDataGPIO2.Frequency, MotorDataGPIO2.Resolution, LEDC_TIMER_MAX, LEDC_AUTO_CLK);
	}

	if (Settings.GPIOData.GetCurrent().WindowOpener.MotorGPIO1.GPIO != GPIO_NUM_0 || Settings.GPIOData.GetCurrent().WindowOpener.MotorGPIO2.GPIO != GPIO_NUM_0)
		GPIO::PWMFadeInstallFunction();

	// Подготовим работу с мотором
	motor_rotates_CLOSE = false;
	motor_rotates_OPEN 	= false;
	motorNeedGo = false;

	currentMotorPosition = adc1_get_raw(SENS_CHANNEL) >> 2;
	TargetMotorPosition = currentMotorPosition;

	UpdateSensorWindowOpener(currentMotorPosition);

	NVS Memory(NVSCommandsDriventWindowOpenerArea);

	// Загрузить счетчик передвижений из NVS
	mov_total =  Memory.GetUInt64Bit(NVSMoveTotal);	 

	// Загрузка скорости двигателя из NVS
	motor_speed =  Memory.GetInt8Bit(NVSMotorSpeed);
	if (motor_speed < 25 || motor_speed > 100)
		motor_speed = 25;

	motor_speed_auto = motor_speed;
	ESP_LOGI(DriventWOTag,"motor_speed: %d", motor_speed);

	// Загрузка напряжения обмотки двигателя из NVS
	motor_voltage =  Memory.GetInt8Bit(NVSMotorVoltage);
	if (motor_voltage < 6 || motor_voltage > 24)
		motor_voltage = VMOTOR;

	ESP_LOGI(DriventWOTag,"motor_voltage: %d", motor_voltage);

	// Загрузка значение максимального тока двигателя *100 мА
	motor_curmax = Memory.GetInt8Bit(NVSMotorCurrentMax);

	if (motor_curmax < 2 || motor_curmax > 30)
		motor_curmax = IPOWER;

	ESP_LOGI(DriventWOTag,"motor_curmax: %d", motor_curmax);

	//!dac_output_enable(DAC_CHANNEL_1);
	//!dac_output_voltage(DAC_CHANNEL_1, (motor_curmax * 8));

	// Измерим напряжение питания
	for (uint8_t i = 0; i < 10; i++)
	{
		power_supply = poverReal();
		FreeRTOS::Sleep(1);
	}

	// Проверка задание перегрузок и инициализируем, если пустое 
	if (Memory.GetInt8Bit(NVSOpenOverloadProtection25) 	== 0) 	Memory.SetInt8Bit(NVSOpenOverloadProtection25, 5);
	if (Memory.GetInt8Bit(NVSCloseOverloadProtection25) == 0)	Memory.SetInt8Bit(NVSCloseOverloadProtection25, 20);

	if (Memory.GetInt8Bit(NVSOpenOverloadProtection50) 	== 0) 	Memory.SetInt8Bit(NVSOpenOverloadProtection50, 10);
	if (Memory.GetInt8Bit(NVSCloseOverloadProtection50) == 0)	Memory.SetInt8Bit(NVSCloseOverloadProtection50, 30);

	if (Memory.GetInt8Bit(NVSOpenOverloadProtection75) 	== 0) 	Memory.SetInt8Bit(NVSOpenOverloadProtection75, 10);
	if (Memory.GetInt8Bit(NVSCloseOverloadProtection75) == 0)	Memory.SetInt8Bit(NVSCloseOverloadProtection75, 30);

	if (Memory.GetInt8Bit(NVSOpenOverloadProtection25) 	== 0) 	Memory.SetInt8Bit(NVSOpenOverloadProtection25, 10);
	if (Memory.GetInt8Bit(NVSCloseOverloadProtection25) == 0)	Memory.SetInt8Bit(NVSCloseOverloadProtection25, 25);

	motor_speed_but = (Memory.GetInt8Bit(NVSOpenMotorSpeedButtons));
	if (motor_speed_but < 25 || motor_speed_but > 100)
			motor_speed_but = 25;
	
	read_overload_set();
	// Загрузка крайних положений
	MinMotorPosition =  Memory.GetUInt16Bit(NVSMinMotorPosition);

	if (MinMotorPosition <= 0 || MinMotorPosition > 1000)
		MinMotorPosition = 30;
	
	ESP_LOGD(DriventWOTag, "MinMotorPosition: %d", MinMotorPosition);

	MaxMotorPosition =  Memory.GetUInt16Bit(NVSMaxMotorPosition);
	
	if (MaxMotorPosition < 10 || MaxMotorPosition > 1000)
		MaxMotorPosition = 900;
	
	ESP_LOGD(DriventWOTag, "MaxMotorPosition: %d", MaxMotorPosition);

	// Определим текущее положения
	TargetProcent = searchProcent();
	ESP_LOGD(DriventWOTag, "TargetProcent =: %d", TargetProcent);

	if (TargetProcent <= 1)
		TargetProcent = 0;

	SetDriventCurrentOpenPercent(TargetProcent);
	
	set_start_close = (Memory.GetInt8Bit(NVSCloseOnStartFlag) == 0) ? false : true;
	set_no_retain	= (Memory.GetInt8Bit(NVSNoRetainFlag) == 0) 	? false : true;
	set_swap_but	= (Memory.GetInt8Bit(NVSSwapButtonsFlag) == 0) 	? false : true;
	set_rain_sens 	= (Memory.GetInt8Bit(NVSEnableRainSensorFlag) == 0) ? false : true;
	set_dual_speed	= (Memory.GetInt8Bit(NVSDualSpeedFlag) == 0) 	? false : true;

	// Устанавливаем Уровень дождя автозакрытия
	setRain = Memory.GetInt8Bit(NVSRainSensorThreshold);
		
	if (setRain > 100)
		setRain = 0;

	if (!set_dual_speed)
		motor_speed_but = motor_speed_auto;
	
	ESP_LOGD(DriventWOTag, "setRain: %d", setRain);
	
	Memory.Commit();

	if (TaskHandle == NULL)
		TaskHandle = FreeRTOS::StartTask(CommandDriventWindowOpenerTask, "DriventWOTask", NULL, 6144, 2);		
}

string CommandDriventWindowOpener_t::GetSettings() {
	NVS Memory(NVSCommandsDriventWindowOpenerArea);

	JSON JSONItem;
	JSONItem.SetFloatItem("MotorSpeedButtons", motor_speed_but);
	JSONItem.SetFloatItem("MotorSpeed", motor_speed);

	JSONItem.SetFloatItem("OpenProtectionValue_25",  Memory.GetInt8Bit(NVSOpenOverloadProtection25));
	JSONItem.SetFloatItem("CloseProtectionValue_25", Memory.GetInt8Bit(NVSCloseOverloadProtection25));

	JSONItem.SetFloatItem("OpenProtectionValue_50",  Memory.GetInt8Bit(NVSOpenOverloadProtection50));
	JSONItem.SetFloatItem("CloseProtectionValue_50", Memory.GetInt8Bit(NVSCloseOverloadProtection50));

	JSONItem.SetFloatItem("OpenProtectionValue_75",  Memory.GetInt8Bit(NVSOpenOverloadProtection75));
	JSONItem.SetFloatItem("CloseProtectionValue_75", Memory.GetInt8Bit(NVSCloseOverloadProtection75));

	JSONItem.SetFloatItem("OpenProtectionValue_100",  Memory.GetInt8Bit(NVSOpenOverloadProtection100));
	JSONItem.SetFloatItem("CloseProtectionValue_100", Memory.GetInt8Bit(NVSCloseOverloadProtection100));

	JSONItem.SetFloatItem("AutoCloseTime", tim_auto_close);
	JSONItem.SetFloatItem("RainSensorTheshold", setRain);

	JSONItem.SetBoolItem("RainSensorEnabled", set_rain_sens);
	JSONItem.SetBoolItem("CloseOnStartEnabled", set_start_close);
	JSONItem.SetBoolItem("RetainEnabled", set_no_retain);
	JSONItem.SetBoolItem("DualSpeedEnabled", set_dual_speed);

	return JSONItem.ToString();
}

void CommandDriventWindowOpener_t::SetSettings(WebServer_t::Response &Result, Query_t &Query) {
	JSON JSONItem(Query.GetBody());

	if (JSONItem.GetKeys().size() == 0)
	{
		Result.SetInvalid();
		return;
	}

	bool IsChanged = false;

	NVS Memory(NVSCommandsDriventWindowOpenerArea);

	ParseJSONByteParam(JSONItem, "MotorSpeedButtons", motor_speed_but, IsChanged, NVSOpenMotorSpeedButtons, Memory);
	ParseJSONByteParam(JSONItem, "MotorSpeed", motor_speed, IsChanged, NVSMotorSpeed, Memory);

	uint8_t Temp;
	ParseJSONByteParam(JSONItem, "OpenProtectionValue_25", Temp, IsChanged, NVSOpenOverloadProtection25, Memory);
	ParseJSONByteParam(JSONItem, "CloseProtectionValue_25", Temp, IsChanged, NVSCloseOverloadProtection25, Memory);

	ParseJSONByteParam(JSONItem, "OpenProtectionValue_50", Temp, IsChanged, NVSOpenOverloadProtection50, Memory);
	ParseJSONByteParam(JSONItem, "CloseProtectionValue_50", Temp, IsChanged, NVSCloseOverloadProtection50, Memory);

	ParseJSONByteParam(JSONItem, "OpenProtectionValue_75", Temp, IsChanged, NVSOpenOverloadProtection75, Memory);
	ParseJSONByteParam(JSONItem, "CloseProtectionValue_75", Temp, IsChanged, NVSCloseOverloadProtection75, Memory);

	ParseJSONByteParam(JSONItem, "OpenProtectionValue_100", Temp, IsChanged, NVSOpenOverloadProtection100, Memory);
	ParseJSONByteParam(JSONItem, "CloseProtectionValue_100", Temp, IsChanged, NVSCloseOverloadProtection100, Memory);

//			JSONItem.SetFloatItem("AutoCloseTime", open_overload_protection_val);
	ParseJSONByteParam(JSONItem, "RainSensorTheshold", setRain, IsChanged,NVSRainSensorThreshold, Memory);

	ParseJSONBoolParam(JSONItem, "RainSensorEnabled", set_rain_sens, IsChanged, NVSEnableRainSensorFlag, Memory);
	ParseJSONBoolParam(JSONItem, "RetainEnabled", set_start_close, IsChanged, NVSCloseOnStartFlag, Memory);
	ParseJSONBoolParam(JSONItem, "CloseOnStartEnabled", set_no_retain, IsChanged, NVSNoRetainFlag, Memory);
	ParseJSONBoolParam(JSONItem, "DualSpeedEnabled", set_dual_speed, IsChanged, NVSSwapButtonsFlag, Memory);

	if (IsChanged)
	{
		Memory.Commit();
		Result.SetSuccess();
	}
	else
		Result.SetInvalid();
}

void CommandDriventWindowOpener_t::ParseJSONByteParam(JSON &JSONItem, string JSONKey, uint8_t &Param, bool &IsChanged, string NVSKey, NVS &NVSHandle)
{
	if (JSONItem.IsItemExists(JSONKey) && JSONItem.IsItemNumber(JSONKey))
	{
		uint8_t Value = JSONItem.GetIntItem(JSONKey);
		Param = Value;

		if (NVSKey != "")
			NVSHandle.SetInt8Bit(NVSKey, Value);

		IsChanged = true;
	}
}

void CommandDriventWindowOpener_t::ParseJSONBoolParam(JSON &JSONItem, string JSONKey, bool &Param, bool &IsChanged, string NVSKey, NVS &NVSHandle)
{
	if (JSONItem.IsItemExists(JSONKey) && JSONItem.IsItemBool(JSONKey))
	{
		bool Value = JSONItem.GetBoolItem(JSONKey);
		Param = Value;

		if (NVSKey != "")
			NVSHandle.SetInt8Bit(NVSKey, Value ? true : false);

		IsChanged = true;
	}
}

/* --> Блок связки с родительским классом WindowOpener_t */
// Отправка данных о позиции открытия окна в глобальный класс

// Отправка данных по положению окна в основной класс
void CommandDriventWindowOpener_t::SetDriventCurrentOpenPercent(uint8_t Value) 
{
	CommandWindowOpener_t* WindowOpenerCommand = (CommandWindowOpener_t*)Command_t::GetCommandByID(0x10);

	if (WindowOpenerCommand != nullptr)
		WindowOpenerCommand->SetCurrentOpenPercent(Value);
}

// Отправка данных в конце изменения положения окна в основной класс
void CommandDriventWindowOpener_t::SetDriventCurrentOpenPercentFinished(uint8_t Value) 
{
	CommandWindowOpener_t* WindowOpenerCommand = (CommandWindowOpener_t*)Command_t::GetCommandByID(0x10);

	if (WindowOpenerCommand != nullptr)
		WindowOpenerCommand->SetCurrentOpenFinished(Value);
}

// Функция, выполняемая при необходимости установить окно в нужное положение
void CommandDriventWindowOpener_t::SetPosition(uint8_t Target) { 
	ESP_LOGI(DriventWOTag, "SetPosition. Target: %d", Target);

	CommandDriventWindowOpener_t::SetPositionCommand(Target, motor_speed);
}

// Функция, выполняемая после вызова /limits-edit/enable
void CommandDriventWindowOpener_t::SetLimitModeEnabledPostActions() {
	ESP_LOGI(DriventWOTag, "Modification of limits: %s", (IsLimitsModifficationEnabled) ? "enabled" : "disabled");
}

// Сбросить настройки двигателя
bool CommandDriventWindowOpener_t::ResetMotorPosition() {
	MinMotorPosition = 30;
	MaxMotorPosition = 900;

	NVS Memory(NVSCommandsDriventWindowOpenerArea);
	Memory.SetUInt16Bit(NVSMinMotorPosition, MinMotorPosition);
	Memory.SetUInt16Bit(NVSMaxMotorPosition, MaxMotorPosition);
	Memory.Commit();

	ESP_LOGI(DriventWOTag, "MinMotorPosition: %d, MaxMotorPosition %d", MinMotorPosition, MaxMotorPosition);
	return true;
}

// Сохранить значение положения Открыто
bool CommandDriventWindowOpener_t::SaveOpenPosition() { 
	MinMotorPosition = currentMotorPosition;

	if (MaxMotorPosition == MinMotorPosition)
		MinMotorPosition += 1;

	ESP_LOGI(DriventWOTag, "MinMotorPosition: %d", MinMotorPosition);

	NVS Memory(NVSCommandsDriventWindowOpenerArea);
	Memory.SetUInt16Bit(NVSMinMotorPosition, MinMotorPosition);
	Memory.Commit();

	return true;
}

// Сохранить значение положения Закрыто
bool CommandDriventWindowOpener_t::SaveClosePosition() { 
	MaxMotorPosition = currentMotorPosition;

	if (MaxMotorPosition == MinMotorPosition)
		MaxMotorPosition += 1;

	ESP_LOGI(DriventWOTag, "MaxMotorPosition: %d", MaxMotorPosition);

	NVS Memory(NVSCommandsDriventWindowOpenerArea);
	Memory.SetUInt16Bit(NVSMaxMotorPosition, MaxMotorPosition);
	Memory.Commit();

	return true;
}

// Вызван API автокалибровки
bool CommandDriventWindowOpener_t::AutoCallibrationStart() { 
	setAutoCalibration = true;	
	return true; 
};

// срабатывает при перегреве устройства
void CommandDriventWindowOpener_t::Overheated() {
	motorStop();
}

/* <-- Блок связки с родительским классом WindowOpener_t */


void CommandDriventWindowOpener_t::CommandDriventWindowOpenerTask(void *TaskData) {
	while (1) 
	{
		CurrentTime = Time::UptimeU();

		Check();
		countLoop++;

		if (!check_but_lock())
		{
			if (Button1 != GPIO_NUM_0 && Button2 != GPIO_NUM_0 
				&& GPIO::Read(Button1) == false && GPIO::Read(Button2) == false)
			{
				motorStop();
				FreeRTOS::Sleep(100);
			}
			else 
			{
				readBUTTON_OPEN();
				readBUTTON_CLOSE();
			}
		}

		MotorGo();
		OverloadCheck();

		FreeRTOS::Sleep(10);
	}
}

// Определение перегрузки
void CommandDriventWindowOpener_t::OverloadCheck()
{
	if ((motor_rotates_CLOSE || motor_rotates_OPEN)) //&& cycle_number<20) //если мотор крутится
	{
		int tim = motor_speed;
		if (motor_speed == 25)
			tim = 50;

		if (CurrentTime - PWM_cycle_Time > tim * 1000)
		{
			PWM_cycle_Time = CurrentTime;
			//  OverloadTimer = CurrentTime;
			uint16_t load = 0;
			if (how_many_curent > 0)
				load = how_many_curent * (power_supply / 10 - 5) / (motor_curmax / 2 + 5);

			if (CurrentTime - OverloadTimer > 600 * 1000)
				load = 101;

			if (CurrentTime - OverloadTimer > 200 * 1000 && emergency_stop)
				load = 102; // тест
			
			if (loadMax < load)
				loadMax = load;

			if (first_cycle)
				first_cycle = false; // тест
			else if (motor_rotates_OPEN)
			{
				if (load > open_overload_protection_val) //сравним измеренную нагрузку двигателя с установленной
				{
					ObstructionDetected = true;
					send_data_after_stop = false;

					motorStop();
					emergency_stop = true;
					motorNeedGo = true;
					// ledcWrite(CRED, LHIGH);  // обозначим перегрузку красным цветом
					TargetMotorPosition = currentMotorPosition + (MaxMotorPosition - MinMotorPosition) / 20; //установим позицию отката
					
					if (TargetMotorPosition > MaxMotorPosition)
						TargetMotorPosition = MaxMotorPosition;

					// TargetProcent = map(TargetMotorPosition, MinMotorPosition, MaxMotorPosition, 0, 100);
					TargetProcent = searchProcent();
					if (TargetProcent >= 99)
						TargetProcent = 100;
					
					send_data_after_stop = true;
					ObstructionCounter++;

					if (ObstructionCounter >= 2)
						motorStop();
				}
			}
			else if (motor_rotates_CLOSE)
			{
				if (load > close_overload_protection_val) //сравним измеренную нагрузку двигателя с установленной
				{
					ObstructionDetected = true;
					send_data_after_stop = false;

					motorStop();
					emergency_stop = true;
					motorNeedGo = true;

					// ledcWrite(CRED, LHIGH); // обозначим перегрузку красным цветом
					TargetMotorPosition = currentMotorPosition - (MaxMotorPosition - MinMotorPosition) / 20; //установим позицию отката
					if (TargetMotorPosition < MinMotorPosition)
						TargetMotorPosition = MinMotorPosition;

					// TargetProcent = map(TargetMotorPosition, MinMotorPosition, MaxMotorPosition, 0, 100);
					TargetProcent = searchProcent();
					if (TargetProcent <= 1)
						TargetProcent = 0;

					send_data_after_stop = true;
					ObstructionCounter++;

					if (ObstructionCounter >= 2)
						motorStop();
				}
			}
		}
	}
}

void CommandDriventWindowOpener_t::Check() {
	static bool 			flag_beg_rain = false;
	static uint64_t			sec = 0;
	static uint32_t 		mov_total_old = 0;
	static uint8_t 			rain_sens_old = 0;


	if (Time::UptimeU() - sec >= 1000 * 1000) // Каждую секунду
	{
		sec = Time::UptimeU();

		timer_auto_close++;
		tim_count++;
		time_total_count++;
		powerLoop = countLoop;
		countLoop = 0;
		
		if (set_start_close && sec < 15 && !setAutoCalibration && TargetProcent > 1)
		{  // в первые 15 секунд после старта управляем автозакрытием по флагу set_start_close
			SetPositionCommand(0, motor_speed_auto); // закрываем окно при старте.
		}

		if (!setAutoCalibration && timer_auto_close / 600 >= tim_auto_close && tim_auto_close != 0 && TargetProcent > 1)
		{ // управляем автозакрытием по timer_auto_close
			SetPositionCommand(0, motor_speed_auto); // закрываем окно по таймеру.
		}

		if (setAutoCalibration) // Запуск автокалибровки
			autoCalibration();

		power_supply = poverReal(); // обновляем значение напряжения питания

		if ((rain_sensor - rain_sens_old) > 1 || (rain_sens_old - rain_sensor > 1))
		{
			rain_sens_old = rain_sensor; // публикуем если данные изменились
		}

		if (set_rain_sens && !flag_beg_rain && !setAutoCalibration && rain_sensor > setRain && TargetProcent > 1)
		{ // закрываем окно по датчику дождя.
			flag_beg_rain = true;
			SetPositionCommand(0, motor_speed_auto);
		}

		if (rain_sensor < setRain)
			flag_beg_rain = false;

		if (mov_locked)
			tim_block++; // Счетчик времени для блокировки перемещений
		else
		{
			tim_block = 0;
			mov_block = false;
		}
		if (flag_tim_dual_but)
			tim_dual_but++; //Счетчик времени нажатия двух кнопок
		}

	if (time_total_count >= 3600)
	{
		// переодическая запись количества перемещений в ЕЕПРОМ если были
		time_total_count = 0;

		if (mov_total_old != mov_total)
		{
			mov_total_old = mov_total;

			NVS Memory(NVSCommandsDriventWindowOpenerArea);
			Memory.SetUInt64Bit(NVSMoveTotal, mov_total);
			Memory.Commit();
		}
	}

	if (tim_count >= 55) // Контрль счетчика количества движений
	{
		tim_count = 0;
		if (count_mov_protec())
		{
			mov_locked = true;
		}
		else
		{
			mov_locked = false;
			mov_block = false;
			//GPIO::PWMSetDuty(CRED, LLOW);
		}
	}

	if (tim_block >= TIME_BLOCK) // Контрль счетчика времени для блокировки по количеству движений
	{
		tim_block = 0;
		mov_block = false;
	}
}

/* 	процедура проверки нажатия двух кнопок на TIME_BUTLOCK сек. 
	для блокировки/разблокировки местного управления.
	На выходе истина или лож после удержания нажатыми обеих кнопок*/
bool CommandDriventWindowOpener_t::check_but_lock()
{
	static bool flag_togle = false;
	static bool set_togle = false;

	if ((GPIO::Read(Button1) == false && GPIO::Read(Button2) == false))
	{
		if (flag_tim_dual_but)
		{
			if (tim_dual_but > TIME_BUTLOCK && !flag_togle)
			{
				if (set_togle)
					set_togle = false;
				else
					set_togle = true;

				flag_togle = true;
			}
			return set_togle;
		}
		else
		{
			flag_tim_dual_but = true;
			tim_dual_but = 0;
			return set_togle;
		}
	}
	else
	{
		flag_tim_dual_but = false;
		tim_dual_but = 0;
		flag_togle = false;
		
		return set_togle;
	}
}

// Чтение кнопок
bool CommandDriventWindowOpener_t::readBUTTON_OPEN()
{
	if (Button1 == GPIO_NUM_0 || Button2 == GPIO_NUM_0)
		return false;
	
	if (GPIO::Read(Button1) == true && GPIO::Read(Button2) == false && !pressBUTTON_OPEN && ((CurrentTime - Time_button) > BOUNCE))
	{
		ESP_LOGI(DriventWOTag, "pressBUTTON_OPEN");

		Time_button 		= CurrentTime;
		pressBUTTON_OPEN 	= true;
		setAutoCalibration 	= false;

		//GPIO::PWMSetDuty(CGREEN, LLOW);
		//GPIO::PWMSetDuty(CRED, LLOW);

		if (motor_rotates_CLOSE || motor_rotates_OPEN)
		{
			motorStop();
		}
		else if (!emergency_stop)
		{
			SetPositionCommand(100, motor_speed_but);
		}
	}

	if ((GPIO::Read(Button1) == false || GPIO::Read(Button2) == true) && pressBUTTON_OPEN && ((CurrentTime - Time_button) > BOUNCE))
	{
		ESP_LOGI(DriventWOTag, "UNpressBUTTON_OPEN");

		if (!IsLimitsModifficationEnabled && (CurrentTime - Time_button) < BUT_LONG)
			ESP_LOGI(DriventWOTag, "Ne tormozim");
		else if ((motor_rotates_CLOSE || motor_rotates_OPEN) && !emergency_stop)
			motorStop();
		
		pressBUTTON_OPEN = false;
		//GPIO::PWMSetDuty(CGREEN, LLOW);
	}

	return pressBUTTON_OPEN;
}

// Чтение кнопок
bool CommandDriventWindowOpener_t::readBUTTON_CLOSE() {
	if (Button1 == GPIO_NUM_0 || Button2 == GPIO_NUM_0)
		return false;

	if (GPIO::Read(Button1) == false && GPIO::Read(Button2) == true && !pressBUTTON_CLOSE && ((CurrentTime - Time_button) > BOUNCE))
	{
		ESP_LOGI(DriventWOTag, "pressButton_СLOSE");
		Time_button = CurrentTime;
		pressBUTTON_CLOSE = true;
		setAutoCalibration = false;

		//GPIO::PWMSetDuty(CGREEN, LLOW);
		//GPIO::PWMSetDuty(CRED, LLOW);

		if (motor_rotates_CLOSE || motor_rotates_OPEN)
		{
			motorStop();
		}
		else if (!emergency_stop)
		{
			SetPositionCommand(0, motor_speed_but);
		}
	}

	if ((GPIO::Read(Button1) == true || GPIO::Read(Button2) == false) && pressBUTTON_CLOSE && ((CurrentTime - Time_button) > BOUNCE))
	{
		ESP_LOGI(DriventWOTag, "UNpressButton_СLOSE");
		
		if (!IsLimitsModifficationEnabled && (CurrentTime - Time_button) < BUT_LONG)
			ESP_LOGI(DriventWOTag, "Ne tormozim");
		else if ((motor_rotates_CLOSE || motor_rotates_OPEN) && !emergency_stop)
			motorStop();

		pressBUTTON_CLOSE = false;

		//GPIO::PWMSetDuty(CGREEN, LLOW);
	}

	return pressBUTTON_CLOSE;
}

// Команда на перемещение привода в требуемое место с требуемой скоростью
void CommandDriventWindowOpener_t::SetPositionCommand(uint8_t Target, uint8_t Speed) {
	ESP_LOGI(DriventWOTag, ">> SetPositionCommand for Target %d and Speed %d", Target, Speed);

	// храним предыдущее значение счетчика движений.
	static uint64_t old_mov_total = mov_total;
	if (Target <= 100)
	{
		if (!pressBUTTON_CLOSE && !pressBUTTON_OPEN && !setAutoCalibration)
		{
			if (mov_count < MOV_LIMIT)
				mov_count += 1;

			if (mov_count >= MOV_LIMIT)
			{
				mov_locked = true;
			}
		}

		ESP_LOGE("TargetProcent", "%d", TargetProcent);

		if (TargetProcent == Target && !mov_block && !ObstructionRow && !setAutoCalibration)
		{ //removed by me
		}
		else if (TargetProcent > Target || (!mov_block && !ObstructionRow) || pressBUTTON_CLOSE || pressBUTTON_OPEN)
		{
			ESP_LOGE("DEBUG","2");

			motor_speed = Speed;
			loadMax = 0;
			read_overload_set();
			TargetProcent = Target;
			mov_total += 1;
			uint8_t fi = fi_table[Target];
			TargetMotorPosition = map(fi, 0, 180, MaxMotorPosition, MinMotorPosition);

			motorNeedGo = true;
			//  OverloadTimer = CurrentTime;  // тест
			if (ObstructionDetected)
			{
				ObstructionDetected = false;

				if (mov_total - old_mov_total == 1)
					obstruct_row_count += 1;
				else if (mov_total - old_mov_total >= 3)
					obstruct_row_count = 0;

				if (obstruct_row_count >= 5)
					ObstructionRow = true;

				old_mov_total = mov_total;
				
				//GPIO::PWMSetDuty(CRED, LLOW);

				ObstructionCounter = 0;
			}

			timer_auto_close = 0; //по новой начинаем счет автозакрытия
			uint8_t search = searchProcent();
		}

		if (mov_locked)
			mov_block = true; //Если замок на передвижение, включаем флаг блокировки на минуту снова.
	}
}

//Крутим двигатель проверяем положение и нагрузку
void CommandDriventWindowOpener_t::MotorGo()
{
	static uint32_t motor_position_sensor_Timer = 0; // Таймер работы двигателя.

	static int OverloadPrevious_motor_position_sensor = 0; // Позиции в RAW после перегрузки
	static int motor_position_sensor = currentMotorPosition; // Новое значение позиции в RAW
	static uint8_t oldcur;

	if ((CurrentTime - motor_position_sensor_Timer) > 5)
	{
		motor_position_sensor_Timer = CurrentTime;
		how_many_curent += ((adc1_get_raw(I_DRIVE_CHANNEL) >> 2) - how_many_curent) >> 2;

		if (motorNeedGo)
		{
			PowerManagement::AddLock("MotorGo");

			motor_position_sensor += ((adc1_get_raw(SENS_CHANNEL) >> 2) - motor_position_sensor) >> 2;

			if (((motor_position_sensor - OverloadPrevious_motor_position_sensor) > 1) || ((OverloadPrevious_motor_position_sensor - motor_position_sensor) > 1))
			{
				OverloadTimer = CurrentTime;
				OverloadPrevious_motor_position_sensor = motor_position_sensor;
			}

			currentMotorPosition = motor_position_sensor;
			uint8_t cur = searchProcent();

			SetDriventCurrentOpenPercent(cur);

			if (cur != oldcur && cur % 5 == 0)
			{
				oldcur = cur;
			}

			if ((currentMotorPosition - TargetMotorPosition > (MaxMotorPosition - MinMotorPosition) / 100) && (currentMotorPosition >= MinMotorPosition))
			{
				if (!motor_rotates_OPEN)
					motorOPEN();
			}
			else if ((TargetMotorPosition - currentMotorPosition > (MaxMotorPosition - MinMotorPosition) / 100) && (currentMotorPosition <= MaxMotorPosition))
			{
				if (!motor_rotates_CLOSE)
					motorCLOSE();
			}
			else
			{
				motorStop();

				SetDriventCurrentOpenPercentFinished(cur);
			}
		}
	}
}

// Крутим двигатель в положение закрыть и проверяем перегрузки
void CommandDriventWindowOpener_t::motorCLOSE()
{
	if (MotorDataGPIO1.GPIO != GPIO_NUM_0)
		GPIO::PWMSetDuty(MotorDataGPIO1.Channel, DHIGH);

	if (MotorDataGPIO2.GPIO != GPIO_NUM_0)
		GPIO::PWMSetDuty(MotorDataGPIO2.Channel, DHIGH);
	
	OverloadCheckCycleStart();

	ESP_LOGI(DriventWOTag, "-start--motor_rotates_CLOSE-");

	motor_rotates_CLOSE = true;
	motor_rotates_OPEN = false;

	if (MotorDataGPIO1.GPIO != GPIO_NUM_0)
		GPIO::PWMSetDuty(MotorDataGPIO1.Channel, DHIGH); // если 1 и ШИМ

	if (MotorDataGPIO2.GPIO != GPIO_NUM_0)
	{
		if (motor_voltage >= power_supply / 10)
			GPIO::PWMSetDuty(MotorDataGPIO2.Channel, (DHIGH - DHIGH * motor_speed / 100)); // если 1 и ШИМ
		else
			GPIO::PWMSetDuty(MotorDataGPIO2.Channel, (DHIGH - motor_voltage * DHIGH * motor_speed / (power_supply * 10))); // если 1 и ШИМ
	}
}

// Крутим двигатель в положение открыть и проверяем перегрузки
void CommandDriventWindowOpener_t::motorOPEN() {
	ESP_LOGI(DriventWOTag, ">> motorOPEN");

	if (MotorDataGPIO1.GPIO != GPIO_NUM_0)
		GPIO::PWMSetDuty(MotorDataGPIO1.Channel, DHIGH);

	if (MotorDataGPIO2.GPIO != GPIO_NUM_0)
		GPIO::PWMSetDuty(MotorDataGPIO2.Channel, DHIGH);

	OverloadCheckCycleStart();

	ESP_LOGD(DriventWOTag, "-start--motor_rotates_OPEN-");

	motor_rotates_OPEN = true;
	motor_rotates_CLOSE = false;
	
	if (MotorDataGPIO2.GPIO != GPIO_NUM_0)
		GPIO::PWMSetDuty(MotorDataGPIO2.Channel, DHIGH); // если 1 и ШИМ

	if (MotorDataGPIO1.GPIO != GPIO_NUM_0)
	{
		if (motor_voltage >= power_supply / 10)
			GPIO::PWMSetDuty(MotorDataGPIO1.Channel, (DHIGH - DHIGH * motor_speed / 100)); // если 1 и ШИМ
		else
			GPIO::PWMSetDuty(MotorDataGPIO1.Channel, (DHIGH - motor_voltage * DHIGH * motor_speed / (power_supply * 10))); // если 1 и ШИМ
	}
}

// Останавливаем двигатель и проверяем положение
void CommandDriventWindowOpener_t::motorStop()
{
	if (MotorDataGPIO1.GPIO != GPIO_NUM_0)
		GPIO::PWMSetDuty(MotorDataGPIO1.Channel, DHIGH);

	if (MotorDataGPIO2.GPIO != GPIO_NUM_0)
		GPIO::PWMSetDuty(MotorDataGPIO2.Channel, DHIGH);
	
	//  currentMotorPosition += ((analogRead(SENS_PIN) >>2) - currentMotorPosition)>>2;
	currentMotorPosition = adc1_get_raw(SENS_CHANNEL) >> 2;
	TargetMotorPosition = currentMotorPosition;


	if (motor_rotates_CLOSE || motor_rotates_OPEN)
	{
		if (send_data_after_stop)
		{
			//pubStatus((addTopics + deviceID + STATE_TOPIC), "STOPPED", true);
			uint8_t search = searchProcent();
			if ((TargetProcent - search) > 1 || (search - TargetProcent) > 1)
			{
				TargetProcent = search;

				//UpdateSensorWindowOpener(search);
			}
		
			FreeRTOS::Sleep(15);

			timer_auto_close = 0;           //по новой начинаем счет автозакрытия
			CurrentProcent = TargetProcent; // AGRO моторчик докрутился
		}
	}

	emergency_stop = false;
	motorNeedGo = false;
	motor_rotates_CLOSE = false;
	motor_rotates_OPEN = false;

	PowerManagement::ReleaseLock("MotorGo");
}

// Автодекрементируемый счетчик количества перемещений до блокирования
bool CommandDriventWindowOpener_t::count_mov_protec()
{
	if (!mov_locked)
	{
		if (mov_count >= MOV_LIMIT)
			return true;
		else
		{
			mov_count -= 1;
			if (mov_count < 0)
				mov_count = 0;
		return false;
		}
	}
	else
	{
		mov_count -= 1;
		
		if (mov_count <= 0)
		{
			mov_count = 0;
			return false;
		}
		else
			return true;
	}
}

// устанавливаем приведенные значения скорости.
void CommandDriventWindowOpener_t::normal_motor_speed_auto()
{
	if (motor_speed_auto < 40) 									{ motor_speed_auto = 25; }
	else if (motor_speed_auto < 60 && motor_speed_auto >= 40)	{ motor_speed_auto = 50; }
	else if (motor_speed_auto < 85 && motor_speed_auto >= 60)	{ motor_speed_auto = 75; }
	else if (motor_speed_auto >= 85)							{ motor_speed_auto = 100;}
}

// устанавливаем значения уровня защит для выбранной скорости.
void CommandDriventWindowOpener_t::write_overload_set()
{
	NVS Memory(NVSCommandsDriventWindowOpenerArea);

	Memory.SetInt8Bit(NVSOpenOverloadProtectionBase + Converter::ToString<uint8_t>(motor_speed), open_overload_protection_val);
	Memory.SetInt8Bit(NVSCloseOverloadProtectionBase + Converter::ToString<uint8_t>(motor_speed), close_overload_protection_val);

	Memory.Commit();
}

// читаем значения уровня защит для выбранной скорости.
void CommandDriventWindowOpener_t::read_overload_set() {
	NVS Memory(NVSCommandsDriventWindowOpenerArea);

	uint8_t MotorSpeedToLoad = motor_speed;

	if (MotorSpeedToLoad != 25 && MotorSpeedToLoad != 50 && MotorSpeedToLoad != 75 && MotorSpeedToLoad != 100)
		MotorSpeedToLoad = 25;

	open_overload_protection_val = Memory.GetInt8Bit(NVSOpenOverloadProtectionBase + Converter::ToString<uint8_t>(motor_speed));
	close_overload_protection_val = Memory.GetInt8Bit(NVSCloseOverloadProtectionBase + Converter::ToString<uint8_t>(motor_speed));
}

//задаем стартовые параметры для опеределения перегрузки
void CommandDriventWindowOpener_t::OverloadCheckCycleStart() { 
	PWM_cycle_Time = CurrentTime;
	OverloadTimer = CurrentTime;
	how_many_curent = 0;
	FreeRTOS::Sleep(1); // Пока нужна для того что бы работал откат
	first_cycle = true;
}

// Перевод показаний потенциометра в проценты
uint8_t CommandDriventWindowOpener_t::searchProcent() {
	if (currentMotorPosition < MinMotorPosition)
		currentMotorPosition = MinMotorPosition;
	else if (currentMotorPosition > MaxMotorPosition)
		currentMotorPosition = MaxMotorPosition;

	uint8_t fi = map(currentMotorPosition, MinMotorPosition, MaxMotorPosition, 180, 0);
	uint8_t left = 0; // задаем левую и правую границы поиска
	uint8_t right = 100;
	uint8_t mid;

	while (left <= right) // пока левая граница не "перескочит" правую
	{
		mid = (left + right) / 2; // ищем середину отрезка

		if (fi == fi_table[mid])
			break; // если ключевое поле равно искомому мы нашли требуемый элемент,выходим из цикла

		if (fi < fi_table[mid])
			right = mid - 1; // если искомое ключевое поле меньше найденной середины, смещаем правую границу, продолжим поиск в левой части
		else
			left = mid + 1; // иначе смещаем левую границу, продолжим поиск в правой части
	}

	return (mid); //Возвращаем результат
}

// Измерение напряжения
uint16_t CommandDriventWindowOpener_t::poverReal() {
	static uint16_t vpoverRead = 1000;
	//!vpoverRead += (adc1_get_raw(V_POWER_CHANNEL) - vpoverRead) >> 2;
	
	return (vpoverRead + 210) / 11;
}

int32_t CommandDriventWindowOpener_t::map(int32_t x, int32_t in_min, int32_t in_max, int32_t out_min, int32_t out_max) {
	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

// очистка блокировки перемещений
void CommandDriventWindowOpener_t::movBlockClear() {
	mov_count = 0;          // очистим счетчик замка блокировки
	obstruct_row_count = 0; // очистим счетчик последовательных перегрузок
	mov_locked = false;
	ObstructionRow = false;
	//GPIO::PWMSetDuty(CRED, LLOW);
}

// Окончание автокалибровки
void CommandDriventWindowOpener_t::endAutoCalibration() {
	ESP_LOGD(DriventWOTag, "[ACalibr] Завершаем на этом калибровку");

	CommandWindowOpener_t* WindowOpenerCommand = (CommandWindowOpener_t*)Command_t::GetCommandByID(0x10);
	if (WindowOpenerCommand != nullptr)
		WindowOpenerCommand->SetCurrentMode(CommandWindowOpener_t::OperationalModeEnum::Basic);

	setAutoCalibration = false;
	step = 0;
	
	if (!set_dual_speed)
		motor_speed_but = motor_speed_auto;
	
	NVS Memory(NVSCommandsDriventWindowOpenerArea);
	Memory.SetInt8Bit(NVSMotorSpeed, motor_speed_auto);
	Memory.Commit();

	SetPositionCommand(0, motor_speed_auto);
}

// Автокалибровки
// запускается каждую секунду при наличии флага setAutoCalibration
void CommandDriventWindowOpener_t::autoCalibration() {
	static bool stepEnd = false;
	if (!setAutoCalibration || flag_calibr_err)
	{
		step = 0;
		return;
	}

	switch (step)
	{
		case 0: // Просто открываем для начала
		{
			movBlockClear();
			motor_speed = 100;
			if (stepEnd)
			{
				close_overload_protection_val = 100;
				open_overload_protection_val = 50;
				stepEnd = false;
			}
			else
			{
				close_overload_protection_val = 50;
				open_overload_protection_val = 20;
			}

			write_overload_set();

			ESP_LOGD(DriventWOTag, "[ACalibr] Начало автокалибровки Устанавливаем защиту на %d", open_overload_protection_val);
			SetPositionCommand(100, motor_speed);
			step = 1;
			break;
		}
		case 1: // Проверяем полноту первичного открытия и пускаем на закрывание
		{
			if (!motor_rotates_CLOSE && !motor_rotates_OPEN)
			{
				if (TargetProcent >= 99 && !ObstructionDetected)
				{
					SetPositionCommand(0, motor_speed);
					step = 2;
					stepEnd = false;
					ESP_LOGD(DriventWOTag, "[ACalibr] Открыли Запускаем первый на скорости 100");
				}
				else
				{
					flag_calibr_err = true;
					stepEnd = true;
					step = 0;

					ESP_LOGE(DriventWOTag, "[ACalibr] Ошибка! Не смогли открыть даже на скорости 100");
				}
			}
			break;
		}
		case 2: // Проверяем полноту закрытия и записываем значения защиты закрытия
		{
			if (!motor_rotates_CLOSE && !motor_rotates_OPEN)
			{
				if (TargetProcent <= 1 && !ObstructionDetected)
				{
					close_overload_protection_val = loadMax + motor_speed / 5;
					
					if (close_overload_protection_val > 100)
						close_overload_protection_val = 100;

					write_overload_set();
					step = 3;
					SetPositionCommand(100, motor_speed);

					ESP_LOGD(DriventWOTag, "[ACalibr] Закрыли на скорости %d", motor_speed);
					ESP_LOGD(DriventWOTag, "[ACalibr] Подсчитали защиту на %d", close_overload_protection_val);
				}
				else
				{
					stepEnd = true;
					step = 3;
					SetPositionCommand(100, motor_speed);

					ESP_LOGD(DriventWOTag, "[ACalibr] Не смогли закрыть на скорости %d", motor_speed);
				}
			}
			break;
		}
		case 3: // Проверяем полноту открытия и записываем значения защиты открытия
		{
			if (!motor_rotates_CLOSE && !motor_rotates_OPEN)
			{
				if (TargetProcent >= 99 && !ObstructionDetected)
				{
					open_overload_protection_val = loadMax + motor_speed / 10;
					
					if (open_overload_protection_val)
						open_overload_protection_val = 100;

					write_overload_set();

					ESP_LOGD(DriventWOTag, "[ACalibr] Открыли на скорости %d", motor_speed);
					ESP_LOGD(DriventWOTag, "[ACalibr] Подсчитали защиту на %d", open_overload_protection_val);

					if (stepEnd)
					{
						motor_speed_auto = (motor_speed == 100) ? motor_speed : motor_speed + 25;
						stepEnd = false;
						endAutoCalibration();
					}
					else
						step = 4;
				}
				else
				{
					ESP_LOGD(DriventWOTag, "[ACalibr] Не смогли открыть на скорости %d", motor_speed);

					write_overload_set();
					motor_speed_auto = (motor_speed == 100) ? motor_speed : motor_speed + 25;
					stepEnd = false;
					endAutoCalibration();
				}
			}
			break;
		}
		case 4: // Снижаем скорость и идем повторять с закрытия
		{
			if (motor_speed > 25)
			{
				motor_speed -= 25;

				ESP_LOGD(DriventWOTag, "[ACalibr] Убавим скорость до %d", motor_speed);
				ESP_LOGD(DriventWOTag, "[ACalibr]Идем на шаг закрытия");

				close_overload_protection_val = 100;
				open_overload_protection_val = 50;
				write_overload_set();
				SetPositionCommand(0, motor_speed);
				step = 2;
			}
			else
			{
				motor_speed_auto = motor_speed;
				endAutoCalibration();
			}
			break;
		}

		default:
		{
			step = 0;
			setAutoCalibration = false;
			break;
		}
	}
}