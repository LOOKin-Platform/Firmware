/*
*
*	Drivent window opener
*	ParnterCode    		= 0xF0
*	DeviceType 			= 0x04 (Window Opener)
*	DeviceModel 		= 0x0 + PartnerCode = 0xF0
*	HardwareRevision 	= any
*
*/

#ifndef COMMANDS_PARTNERS_WINDOWOPENER_DRIVENT
#define COMMANDS_PARTNERS_WINDOWOPENER_DRIVENT

#include "CommandWindowOpener.h"

#include "WebServer.h"
#include "JSON.h"
#include "HardwareIO.h"
#include "Query.h"

#include <driver/dac.h>

#define	NVSCommandsDriventWindowOpenerArea 		"DriventWO"
#define NVSMoveTotal							"move_total"
#define NVSMotorSpeed							"motor_speed"
#define NVSOpenMotorSpeedButtons				"motor_speed_btn"
#define NVSMotorVoltage							"motor_voltage"
#define NVSMotorCurrentMax						"motor_curr_max"
#define NVSMinMotorPosition						"min_motor_pos"
#define NVSMaxMotorPosition						"max_motor_pos"

#define NVSOpenOverloadProtectionBase			"overload_o_"
#define NVSOpenOverloadProtection25				"overload_o_25"
#define NVSOpenOverloadProtection50				"overload_o_50"
#define NVSOpenOverloadProtection75				"overload_o_75"
#define NVSOpenOverloadProtection100			"overload_o_100"

#define NVSCloseOverloadProtectionBase			"overload_c_"
#define NVSCloseOverloadProtection25			"overload_c_25"
#define NVSCloseOverloadProtection50			"overload_c_50"
#define NVSCloseOverloadProtection75			"overload_c_75"
#define NVSCloseOverloadProtection100			"overload_c_100"

#define NVSRainSensorThreshold					"rain_threshold"

#define NVSCloseOnStartFlag						"close_on_start"
#define NVSNoRetainFlag							"no_mqtt_retain"
#define NVSSwapButtonsFlag						"swap_buttons"
#define NVSEnableRainSensorFlag					"rain_s_enable"
#define NVSDualSpeedFlag						"set_dual_speed"

#define V_POWER 								GPIO_NUM_5 			//!GPIO_NUM_35         // Датчик Напряжение питания
#define V_POWER_CHANNEL							ADC_CHANNEL_7	 	//!ADC1_CHANNEL_7	// ADC Канал датчика напряжение питания
#define RAINSENSOR 								GPIO_NUM_30 		//! GPIO_NUM_33      	// Датчик дождя
#define I_DRIVE 								GPIO_NUM_29 		//! GPIO_NUM_32         // Датчик тока нагрузки
#define I_DRIVE_CHANNEL							ADC1_CHANNEL_4		// ADC канал датчика тока нагрузки
#define V_REF 									GPIO_NUM_25			// Источник опорного Напряжение датчика тока
#define DHIGH 									1024         		// Мах. уровень ШИМ двигателя
#define LHIGH 									512          		// Мах. уровень ШИМ для светодиодов
#define LLOW 									1024          		// Мin. уровень ШИМ для светодиодов
#define SENS_PIN 								GPIO_NUM_28 		//!GPIO_NUM_34        	// Датчик положение мотора
#define SENS_CHANNEL							ADC1_CHANNEL_6		// ADC канал для датчика мотора
#define VMOTOR 									6           		// Рабочее Напряжение двигателя
#define IPOWER 									10          		// Максимальный ток двигателя дефолт
#define BOUNCE 									100 * 1000         	// Время антидребезга
#define TIME_BUTLOCK 							3     				// Время удержания кнопок секунд для блокировки кнопок
#define BUT_LONG								500 * 1000       	// Время длинного нажатия

class CommandDriventWindowOpener_t : public CommandWindowOpener_t {
	private:
		inline static uint8_t 	tim_auto_close 					= 0;		// значение времени автозакрытия 10 мин.
		inline static uint8_t 	tim_dual_but					= 0;		// значение таймера двойного нажатия кнопок

		inline static uint64_t 	CurrentTime						= 0;		// Счетчик времени
		inline static uint64_t 	Time_button						= 0;      	// Счетчик времени нажатой кнопки

		inline static uint16_t 	countLoop						= 0;		// Cчетчик Циклов
		inline static uint16_t 	powerLoop						= 0;		// значение счетчика Циклов
		inline static uint8_t 	tim_block						= 0;		// значение таймера запрета на движение
		inline static uint64_t 	timer_auto_close				= 0;		// значение таймера автозакрытия сек.
		inline static uint64_t	mov_total						= 0;		// значение счетчика движений.
		inline static uint8_t 	tim_count						= 0;		// значение таймера счетчика движений
		inline static uint8_t 	obstruct_row_count				= 0;		// значение  счетчика последовательных перегрузок
		inline static uint16_t	time_total_count				= 0;		// значение таймера перезаписи счетчика в ЕЕПРОМ

		inline static uint8_t 	motor_speed						= 25;		// Скорость привода
		inline static uint8_t 	motor_speed_but					= motor_speed;	// Настройки Скорость привода От кнопок
		inline static uint8_t 	motor_speed_auto				= motor_speed;	// Настройки Скорость привода автоматизации
		inline static uint8_t 	ObstructionCounter				= 0;		// значение  счетчика перегрузок
		inline static uint8_t 	motor_voltage					= 0;		// значение настройки напряжения обмотки двигателя
		inline static uint16_t	power_supply					= 0;		// значение измеренного напряжения питания
		inline static uint8_t 	motor_curmax					= 0;		// значение настройки аппаратного ограничения Максимального тока
		inline static uint8_t 	close_overload_protection_val	= 0;		// текущее значение настройки уровня срабатывания защиты перегрузки при закрытии
		inline static uint8_t 	open_overload_protection_val	= 0;		// текущее значение настройки уровня срабатывания защиты перегрузки при открытии
		inline static uint8_t 	loadMax							= 0;		// максимальное значение датчика нагрузки для автокалибровки
		inline static int8_t 	mov_count						= 0;		// значение первичного счетчика движений
		inline static uint8_t 	step							= 0;		// Счетчик шагов автокалибровки
		inline static uint8_t 	setRain							= 0;		// Уровень срабатывания датчика дождя
		inline static uint8_t 	rain_sensor						= 0;		// Показания датчика дождя

		inline static bool 		ObstructionDetected				= false;	// флаг перегрузки
		inline static bool 		ObstructionRow					= false;	// флаг последовательных перерузок
		inline static bool 		first_cycle						= true;		// флаг первого цикла измерения зашиты
		inline static bool 		mov_locked						= false;	// флаг сработавшего замка движения, снимаем сбросом или в веб
		inline static bool 		mov_block						= false;	// флаг блокировки движения
		inline static bool 		set_start_close 				= false;	// флаг автозакрывания при включении питания.
		inline static bool 		set_no_retain 					= false;	// флаг не пускать retain
		inline static bool 		set_swap_but 					= false;	// флаг смены кнопок
		inline static bool 		set_allow_did 					= false;	// флаг разрешения смены девайсИД
		inline static bool 		set_rain_sens					= false;	// флаг разрешения датчика дождя
		inline static bool 		flag_alarm 						= false;	// флаг проверки ошибки
		inline static bool 		emergency_stop 					= false;	// флаг аварийной остановки
		inline static bool 		set_discover 					= false;	// флаг разрешения discover
		inline static bool 		set_dual_speed 					= false;	// флаг двух скоростей.
		inline static bool 		flag_tim_dual_but 				= false;	// флаг cработало нажатие обеих кнопок
		inline static bool 		pressBUTTON_CLOSE 				= false;	// флаг нажата кнопка закрыть
		inline static bool 		pressBUTTON_OPEN 				= false;	// флаг нажата кнопка открыть
		inline static bool 		motor_rotates_CLOSE				= false;	// флаг идет вращение к закрыть
		inline static bool 		motor_rotates_OPEN				= false;	// флаг идет вращение к открыть
		inline static bool 		motorNeedGo						= false;	// флаг требуется перемещение
		inline static bool 		setAutoCalibration				= false;	// флаг включения автокалибровки
		inline static bool 		flag_calibr_err					= false;	// флаг ошибки автокалибровки
		inline static bool 		send_data_after_stop 			= true; 	// флаг признак - передать топики после останова

		// ----------Переменные для позиционирования-------------
		inline static uint8_t 	TargetProcent 					= 0;		// Требемая позиция в %
		inline static uint8_t 	CurrentProcent 					= 0;		// Требемая позиция в %
		inline static uint16_t 	MaxMotorPosition				= 900;		// Max позиция в RAW
		inline static uint16_t 	MinMotorPosition				= 30;		// Min позиция в RAW
		inline static uint16_t 	TargetMotorPosition				= 0;		// Требемая позиция в RAW
		inline static uint16_t 	currentMotorPosition			= 0;		// Текущая позиция в RAW

		static constexpr uint8_t TIME_BLOCK = 60; 							// Время секунд блокировки движения
		static constexpr uint8_t MOV_LIMIT	= 45;       					// количество движений до блокировки
		static constexpr uint8_t fi_table[] = {0, 11, 16, 20, 23, 26, 28, 31, 33, 35, 37, 39, 41, 42, 44, 46, 47, 49, 50, 52, 53, 55, 56, 57, 59, 60, 61, 63, 64, 65, 66, 68, 69, 70, 71, 73, 74, 75, 76, 77, 78, 80, 81, 82, 83, 84, 85, 87, 88, 89, 90, 91, 92, 93, 95, 96, 97, 98, 99, 100, 102, 103, 104, 105, 106, 107, 109, 110, 111, 112, 114, 115, 116, 117, 119, 120, 121, 123, 124, 125, 127, 128, 130, 131, 133, 134, 136, 138, 139, 141, 143, 145, 147, 149, 152, 154, 157, 160, 164, 169, 180};

		inline static uint8_t 	TargetProcentReceive			= 0; 		// 0-100%
		inline static uint64_t 	OverloadTimer					= 0;		// Счетчик времени перегтрузки

		//================ Датчик тока ==================
		inline static int			how_many_curent				= 0;
		inline static uint64_t 		PWM_cycle_Time				= 0;

		inline static TaskHandle_t 	TaskHandle					= 0;

		inline static Settings_t::GPIOData_t::WindowOpener_t::GPIO_t MotorDataGPIO1;
		inline static Settings_t::GPIOData_t::WindowOpener_t::GPIO_t MotorDataGPIO2;

		inline static gpio_num_t Button1 = GPIO_NUM_0; // Close button
		inline static gpio_num_t Button2 = GPIO_NUM_0; // Open button

		inline static bool IsInited = false;
		
	public:
		CommandDriventWindowOpener_t();

		void 	InitSettings() override;
		string 	GetSettings() override;
		void 	SetSettings(WebServer_t::Response &Result, Query_t &Query) override; 

		void ParseJSONByteParam(JSON &JSONItem, string JSONKey, uint8_t &Param, bool &IsChanged, string NVSKey, NVS &NVSHandle);

		void ParseJSONBoolParam(JSON &JSONItem, string JSONKey, bool &Param, bool &IsChanged, string NVSKey, NVS &NVSHandle);

		/* --> Блок связки с родительским классом WindowOpener_t */
		// Отправка данных о позиции открытия окна в глобальный класс		
		// Отправка данных по положению окна в основной класс
		static void SetDriventCurrentOpenPercent(uint8_t Value);
		
		// Отправка данных в конце изменения положения окна в основной класс
		static void SetDriventCurrentOpenPercentFinished(uint8_t Value);

		// Функция, выполняемая при необходимости установить окно в нужное положение
		void SetPosition(uint8_t Target) override;

		// Функция, выполняемая после вызова /limits-edit/enable
		void SetLimitModeEnabledPostActions() override;

		// Сбросить настройки двигателя
		bool ResetMotorPosition() override;

		// Сохранить значение положения Открыто
		bool SaveOpenPosition() override;

		// Сохранить значение положения Закрыто
		bool SaveClosePosition() override;

		// Вызван API автокалибровки
		bool AutoCallibrationStart() override; 
		
		// срабатывает при перегреве устройства
		void Overheated() override;

		/* <-- Блок связки с родительским классом WindowOpener_t */

		static void CommandDriventWindowOpenerTask(void *TaskData);
		 
		// Определение перегрузки
		static void OverloadCheck();

		static void Check();
		
		
		/* 	процедура проверки нажатия двух кнопок на TIME_BUTLOCK сек. 
			для блокировки/разблокировки местного управления.
			На выходе истина или лож после удержания нажатыми обеих кнопок*/
		static bool check_but_lock();
		
		// Чтение кнопок
		static bool readBUTTON_OPEN();

		// Чтение кнопок
		static bool readBUTTON_CLOSE();		

		// Команда на перемещение привода в требуемое место с требуемой скоростью
		static void SetPositionCommand(uint8_t Target, uint8_t Speed);

		//Крутим двигатель проверяем положение и нагрузку
		static void MotorGo();

		// Крутим двигатель в положение закрыть и проверяем перегрузки
		static void motorCLOSE();

		// Крутим двигатель в положение открыть и проверяем перегрузки
		static void motorOPEN();

		// Останавливаем двигатель и проверяем положение
		static void motorStop();

		// Автодекрементируемый счетчик количества перемещений до блокирования
		static bool count_mov_protec();

		// устанавливаем приведенные значения скорости.
		void normal_motor_speed_auto();

		// устанавливаем значения уровня защит для выбранной скорости.
		static void write_overload_set();

		// читаем значения уровня защит для выбранной скорости.
		static void read_overload_set();

		//задаем стартовые параметры для опеределения перегрузки
		static void OverloadCheckCycleStart();

		// Перевод показаний потенциометра в проценты
		static uint8_t searchProcent();

		// Измерение напряжения
		static uint16_t poverReal();

		static int32_t map(int32_t x, int32_t in_min, int32_t in_max, int32_t out_min, int32_t out_max);

		// очистка блокировки перемещений
		static void movBlockClear();

		// Окончание автокалибровки
		static void endAutoCalibration();

		// Автокалибровки
		// запускается каждую секунду при наличии флага setAutoCalibration
		static void autoCalibration();
};


#endif
